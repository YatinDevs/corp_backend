<?php

namespace App\Filament\Resources\ComboPackResource\Pages;

use App\Filament\Resources\ComboPackResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateComboPack extends CreateRecord
{
    protected static string $resource = ComboPackResource::class;
}
